# RZSDH
Robust zero-shot discrete hashing with noisy labels for cross-modal retrieval

Please contact us at yongkailing@163.com for questions.
