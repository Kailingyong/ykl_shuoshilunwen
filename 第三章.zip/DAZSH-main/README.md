# DAZSH

Discrete asymmetric zero-shot hashing with application to cross-modal retrieval

Please contact us at yongkailing@stu.kust.edu.cn for questions.
