# RSMFH

Robust Supervised Matrix Factorization Hashing with application to Cross-modal Retrieval

Please contact us at yongkailing@163.com for questions.
